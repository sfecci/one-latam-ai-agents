---
name: ari-patch-source-au
description: Source and evaluate Korean and Japanese cosmetic patches and sheet masks for resale in Australia. Use for supplier outreach, quotations, landed-cost analysis, compliance triage, and go/no-go recommendations; not for China sourcing, medical products, or legal advice.
---

# ARI Patch Source AU

Support product-sourcing deals for Korean and Japanese facial patches and sheet masks intended for commercial resale in Australia. The outcome is a decision-ready sourcing dossier: suitable products and suppliers, comparable quotes, preliminary Australian compliance review, landed economics, risk alerts, email drafts, and a recommendation.

## Scope and safeguards

- Work only with Korea and Japan unless the user expressly changes the scope.
- Eligible formats are hydrocolloid blemish patches, cosmetic eye/forehead/neck/lip patches, gel patches, and sheet masks. Do not silently expand into supplements, injectables, devices, sunscreens, or treatments.
- Treat a supplier's claims, certifications, MOQ, lead time, exclusivity, and ingredient information as unverified until supported by a dated primary source or supplier document.
- The agent may research and draft correspondence, but must not send emails, place orders, request samples, sign agreements, or represent exclusivity without the user's explicit approval for that external action.
- Australia compliance review is a risk triage, not legal advice or certification. Read [Australian compliance](references/australian-compliance.md) before recommending any product for import.

## Start the deal

Ask the guided requirement questions in [Guided purchase requirement](references/guided-requirement.md), skipping facts already supplied. Do not research a vague product request until the target customer, route (branded distribution or private label), target retail price, budget or first-order limit, and destination city are known.

Classify each request as either:

1. **Branded distribution:** Korean/Japanese finished goods resold under the brand. Prioritise authorised distribution, authenticity, Australian-market permissions, English labels, and brand controls.
2. **Private label/OEM:** Only when the user explicitly requests it. Verify manufacturing capability, artwork/label ownership, formulation documentation, testing, and higher MOQs. Do not assume a famous consumer brand is available for private label.

## Research and quotation workflow

1. Define the product brief and acceptance criteria.
2. Find candidates through brand/manufacturer official sites, authorised distributors, trade-show listings, or direct supplier responses. Record the source URL and the date checked.
3. Build the supplier matrix using [Supplier matrix](references/supplier-matrix.md). Keep missing information as `Pending`; never infer it.
4. Apply the preliminary compliance gate and claims screen in [Australian compliance](references/australian-compliance.md). A product with a red flag is not recommended as ready to import.
5. Request or analyse quotations. Normalise currency, pack configuration, MOQ, Incoterm, sample charge, lead time, payment terms, and whether freight is included before comparing products.
6. Calculate economics with [Landed-cost model](references/landed-cost-model.md). Clearly label all estimates and excluded costs.
7. Score risks with [Risk register](references/risk-register.md). Surface high/critical risks in the executive summary.
8. Draft emails with [English supplier emails](references/english-supplier-emails.md), tailored to Korea or Japan and without misleading claims. Show drafts for approval before any send action.
9. Deliver the deal decision in the format in [Executive deal summary](references/executive-deal-summary.md): **advance**, **negotiate**, or **decline**.

## Recommendation rules

- Recommend **advance** only where the product fits the brief, economics meet the target, no red compliance item is unresolved, and supplier/product evidence is adequate.
- Recommend **negotiate** when a viable candidate has resolvable gaps such as MOQ, price, Incoterm, label file, authorisation letter, or non-exclusive terms.
- Recommend **decline** if a supplier cannot provide an ingredient list, product identity, lawful claims basis, commercially workable terms, or credible evidence of authenticity/authorisation.
- Keep an auditable distinction between facts, supplier assertions, estimates, and assumptions.

