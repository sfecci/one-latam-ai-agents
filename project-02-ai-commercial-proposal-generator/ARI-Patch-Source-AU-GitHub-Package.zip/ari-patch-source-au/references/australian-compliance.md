# Australian compliance triage for cosmetic patches and sheet masks

This is a preliminary sourcing screen, not legal advice. Regulations and product classification can change; verify current requirements with the relevant Australian authority or qualified adviser before import or sale.

## First classification gate: cosmetic versus therapeutic good

The exact product, ingredients, intended use, labelling, and advertising claims matter. The TGA distinguishes cosmetics from therapeutic goods; a product making therapeutic claims may fall into a different regulatory framework. For patch and mask sourcing, treat these as red flags pending specialist review:

- claims to treat acne/pimples, heal skin, cure, prevent disease, reduce inflammation, repair a defect, or remove wrinkles;
- drug-like active ingredients or claims that influence body function;
- any sunscreen/SPF claim, unless its regulatory classification and evidence have been confirmed.

Do not rewrite a supplier’s claim into a safer claim and treat that alone as compliance. Record the source claim and propose a compliant-marketing review.

Primary sources:

- TGA, [Determining if your product is a cosmetic or therapeutic good](https://www.tga.gov.au/resources/guidance/determining-if-your-product-cosmetic-or-therapeutic-good)
- TGA, [What are therapeutic goods?](https://www.tga.gov.au/products/regulations-all-products/regulation-essentials/what-are-therapeutic-goods)

## AICIS: imported cosmetic ingredients

For commercial sale of imported cosmetics, the Australian importer may need to register with the Australian Industrial Chemicals Introduction Scheme (AICIS), including for finished, branded, packaged cosmetics. AICIS says importers must assess/categorise relevant industrial chemicals, meet any reporting/declaration and record-keeping obligations, and retain records. Confirm the importer of record and do not assume an overseas supplier’s approval satisfies Australian obligations.

Minimum evidence to obtain before a go decision:

- full product INCI ingredient list and, where needed, ingredient identity information;
- manufacturer, product, batch and shelf-life/expiry traceability;
- Australian importer of record and AICIS status/pathway;
- category/conditions and missing-information list for each product.

Primary source: AICIS, [Personal care, skincare, make-up and other cosmetic products](https://www.industrialchemicals.gov.au/cosmetics-and-soap/personal-care-skincare-make-and-other-cosmetic-products).

## Consumer information, safety and claims

Cosmetics supplied in Australia have consumer product safety and mandatory cosmetic-labelling obligations. Check current requirements for ingredient disclosure and consumer-facing information, and retain the evidence used. Label content must not conflict with the classification decision or make unsupported therapeutic claims.

Primary sources:

- AICIS, [Labelling, SDS and packaging](https://www.industrialchemicals.gov.au/help-and-guides/labelling-sds-and-packaging)
- TGA, [Cosmetics or therapeutic goods: guidance for advertisers and suppliers](https://www.tga.gov.au/sites/default/files/2024-06/cosmetics-therapeutic-goods-guidance-for-advertisers-suppliers.pdf)

## Gate outcome

| Outcome | Meaning |
|---|---|
| Green — proceed to commercial negotiation | Cosmetic positioning is credible and the supplier can provide complete product, ingredient, traceability and label evidence; Australian importer pathway is identified. |
| Amber — negotiate / investigate | Commercial fit may exist, but documents, classification, artwork or importer pathway are incomplete. No import recommendation yet. |
| Red — do not recommend import | Therapeutic/sunscreen claim is unresolved, ingredients are unavailable, label evidence is absent, or source/authenticity cannot be established. |

