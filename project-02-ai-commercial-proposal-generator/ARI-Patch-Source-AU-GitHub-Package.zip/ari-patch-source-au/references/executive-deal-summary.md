# Executive deal summary and recommendation

Use this structure after the supplier matrix, compliance gate, economics, and risks are complete.

## Deal identity

- Deal name and date
- Product category and target Australian customer
- Korea/Japan sourcing scope
- Route: branded distribution or private label/OEM
- Decision owner and destination city

## Recommended option

Name the supplier, product/SKU/pack configuration, country, evidence status, and why it best fits the approved brief. Name one alternative if it is commercially credible.

## Commercial snapshot

| Item | Value | Basis / evidence |
|---|---:|---|
| MOQ and first-order quantity |  |  |
| Product value |  |  |
| Estimated landed cost per saleable unit |  |  |
| Target retail price (ex GST) |  |  |
| Product-only gross margin |  |  |
| Margin after known variable selling costs |  |  |
| Lead time to Australian destination |  |  |

## Compliance and quality status

State the classification screen result (green/amber/red), claims found, AICIS/importer position, label/ingredient status, traceability, and every unresolved document. Do not use “compliant” unless a qualified authority/adviser has actually determined it.

## Main risks and actions

List high and critical risks with the proposed mitigation, owner, and decision deadline. Include MOQ, claims, ingredients, freight/Incoterm, authorisation, quality evidence, exclusivity, and launch timing when relevant.

## Final recommendation

Choose exactly one:

- **Advance:** proceed to the next authorised commercial step; list conditions still to be documented.
- **Negotiate:** state the specific changes/documents needed and the walk-away threshold.
- **Decline:** state the decision evidence and recommend whether to pursue an alternative candidate.

End with the single next action the user must approve, such as “approve the attached supplier enquiry draft” or “authorise a sample request within an AUD [amount] cap.”
