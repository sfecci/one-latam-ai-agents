# English supplier emails

Personalise every bracketed item and remove untrue statements. Do not send without the user's explicit approval. Keep a professional, direct style; state that the request concerns Australia and avoid asking for exclusivity as if it already exists.

## Initial branded-distribution enquiry

**Subject:** Australia distribution enquiry — [Brand / product category]

Dear [Name/Team],

I am researching [hydrocolloid blemish patches / cosmetic gel patches / sheet masks] for potential resale in Australia. We are interested in learning whether you work with Australian distributors or retailers for [brand/product range].

Could you please share:

- your current catalogue and wholesale price list;
- MOQ by SKU and any mixed-SKU options;
- export terms, Incoterms, lead time and sample policy;
- available product information: full INCI ingredients, pack details, shelf life, batch traceability and English label/artwork files;
- any certifications or quality documents available for the specific products;
- whether Australian distribution is available and any territory, online-sales or authorised-reseller requirements.

Our initial focus is [brief product and customer description]. Please let me know the appropriate contact if another team handles export partnerships.

Kind regards,

[Name]
[Business]
[City, Australia]
[Website/contact details]

## Follow-up after five to seven business days

**Subject:** Follow-up — Australia distribution enquiry for [Brand]

Dear [Name],

I am following up on my enquiry of [date] regarding [product category] for Australia. We remain interested in reviewing your export terms and product documentation.

Could you let me know whether this opportunity is handled by your team, or direct me to the appropriate contact?

Kind regards,

[Name]

## Quote clarification / negotiation

**Subject:** Clarification on quotation [number/date] — [Product]

Dear [Name],

Thank you for your quotation. To evaluate it accurately, could you please confirm the following:

- unit and carton pack configuration, currency and quote-validity date;
- MOQ per SKU and whether a mixed-SKU trial order is possible;
- Incoterm and named place, and whether freight/insurance are included;
- production lead time after payment/artwork approval;
- sample cost and how it is credited, if applicable;
- full INCI list, English-ready label/artwork, shelf life, batch traceability and product quality documents;
- whether the offer authorises resale in Australia and any restrictions on channels or marketplaces.

If a smaller first order or mixed-SKU MOQ is possible, please share the applicable pricing and terms.

Kind regards,

[Name]

