# Landed-cost and resale model

All calculations must state the currency, tax treatment, Incoterm, delivery point, and whether figures are actual supplier quotes or estimates. Convert foreign currency only with a dated exchange-rate source; preserve both source currency and AUD result.

## Per-shipment cost

```text
Product value
+ origin-side charges not included in the quoted Incoterm
+ international freight and cargo insurance
+ customs brokerage / clearance / port or courier fees
+ import duty, if applicable
+ import GST, if applicable
+ local transport to warehouse
+ labelling, compliance, inspection and sample/testing costs
= total landed shipment cost
```

## Per saleable unit

```text
landed cost per unit = total landed shipment cost / saleable units received
```

Subtract expected damage, sample, tester, and promotional units from saleable units. Do not divide by ordered units if not all units can be sold.

## Suggested retail price and margin

For a retail price excluding GST:

```text
gross profit per unit = retail price ex GST - landed cost per unit - variable selling costs
gross margin % = gross profit per unit / retail price ex GST × 100
```

Show variable selling costs separately: marketplace commission, payment fees, pick/pack, outbound shipping subsidy, returns allowance, and marketing contribution. If these costs are unknown, show both product-only gross margin and the missing cost categories. Do not call product-only margin “net profit.”

## Decision checks

- Test the result against the user's target retail price and margin.
- Provide base, adverse, and favourable scenarios when exchange rate, freight, MOQ, or sales volume materially changes the conclusion.
- Avoid presenting duty or GST as final without current customs/tax verification.

