# Guided purchase requirement

Gather answers stage by stage. Confirm the completed stage briefly before moving on. Do not ask for information already present in the user's brief.

## 1. Product and customer

- Which format: hydrocolloid blemish patch, eye/forehead/neck/lip patch, gel patch, sheet mask, or a mixed assortment?
- Who is the Australian target customer (age range, skin concern, price sensitivity, sales channel)?
- Desired positioning: accessible, mid-market, premium, salon/clinic retail, or trend-led K/J-beauty?
- Is the preference Korea, Japan, or a comparison of both?
- Non-negotiable preferences: ingredients to include/avoid, fragrance-free, vegan, packaging language, pack size, and appearance.

## 2. Commercial route

- Branded distribution or private label/OEM?
- Target retail price per unit or pack in AUD and desired gross-margin target.
- First-order budget or maximum order value in AUD.
- Maximum acceptable MOQ per SKU and number of SKUs.
- Desired exclusivity, if any, and the territory sought.

## 3. Logistics and timing

- Destination city/postcode in Australia and preferred delivery point (port, warehouse, fulfilment partner).
- Target launch date and latest acceptable delivery date.
- Preferred shipment method, if known: express courier, air freight, or sea freight.
- Whether the budget must include freight, customs clearance, storage, GST, and local fulfilment.

## 4. Compliance and evidence

- Is there an Australian legal entity/importer of record already registered with AICIS, or should this be treated as a pre-import feasibility review?
- Are complete INCI ingredients, English-ready artwork, safety/quality documentation, and batch/expiry details mandatory before selection? Default: yes.
- Are therapeutic claims such as treatment of acne, healing, curing, or wrinkle removal disallowed? Default: yes, unless specialist regulatory advice is obtained.

## Confirmation output

Restate: product brief, market, route, commercial limits, destination, dates, and red-line requirements. Mark assumptions explicitly and request confirmation before contacting suppliers.

