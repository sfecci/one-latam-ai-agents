# Risk register and alerts

Classify each risk as low, medium, high, or critical. Include evidence, impact, mitigation, owner, and the point at which work must stop.

| Risk | Alert trigger | Minimum mitigation |
|---|---|---|
| MOQ / cash exposure | MOQ exceeds budget, sell-through capacity, or storage capacity | Negotiate mixed-SKU MOQ, trial order, staged shipment, or decline |
| Product claims | “Treats acne”, “heals”, “removes wrinkles”, disease/medical language, or unclear intended use | Pause recommendation; obtain regulatory review and use only approved positioning |
| Ingredients / AICIS | No complete INCI list, unfamiliar ingredient, or no documented importer pathway | Do not import; obtain full formulation/INCI and perform AICIS assessment |
| Labels | No ingredient list or consumer information suitable for Australia | Obtain compliant artwork/over-label plan before order |
| Authenticity / authorisation | Grey-market source, unverifiable brand authority, no supply-chain proof | Obtain written authorisation or use an authorised channel |
| Quality / safety | No batch traceability, shelf-life, manufacturing evidence, or complaint process | Request documents/samples; use independent review where appropriate |
| Logistics | DDP ambiguity, missing named place, volatile freight, short shelf life | Specify Incoterm and destination; quote freight separately; include buffer |
| Exclusivity | Supplier promises exclusivity informally or with minimum-purchase obligations | Require a written, reviewed agreement before relying on it |
| Timing | Lead time cannot meet launch date or production capacity is unconfirmed | Confirm production slot and milestones in writing |
| Currency / price | Quote is expired, currency unhedged, or price excludes key fees | Reprice and run sensitivity analysis |

High and critical items must appear in the executive summary. Critical items block an **advance** decision.

