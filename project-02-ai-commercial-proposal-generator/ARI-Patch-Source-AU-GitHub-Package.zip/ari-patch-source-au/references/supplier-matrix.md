# Supplier and quotation matrix

Create one row per product/supplier/pack configuration. Do not compare quotes until the unit basis is made consistent.

| Field | What to record |
|---|---|
| Supplier and country | Legal name, Korea/Japan location, website, contact, source/date checked |
| Product | Brand, product name, format, SKU, pack contents, net content, intended cosmetic use |
| Route | Branded distribution or private label/OEM |
| Evidence | Catalogue, official product page, authorisation/distribution proof, quotation number/date |
| Claims screen | Exact proposed claims; cosmetic / review required / red flag |
| Ingredients and label | Full INCI received, English label/artwork available, warnings, batch/expiry data |
| Quality evidence | GMP/ISO or other evidence supplied; document issuer/date; never treat a logo as verification |
| Commercials | Currency, unit price, pack size, MOQ, sample cost, payment terms, price validity |
| Delivery | Incoterm and named place, production lead time, estimated transit time, freight included/excluded |
| Distribution | Territory, exclusivity request, restrictions, MAP/online marketplace restrictions |
| Compliance readiness | AICIS/claims/label status, missing documents, owner and next action |
| Economics | Landed cost per saleable unit, proposed retail price, gross margin before/after GST assumptions |
| Decision | Advance / negotiate / decline, rationale, next action |

Use `Pending`, `Supplier assertion`, `Verified document`, or `Estimate` for evidence status. Never leave a blank that could be mistaken for approval.

