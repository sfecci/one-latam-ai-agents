# ARI Proposal Generator

Skill de Codex para crear propuestas comerciales de Oracle Cloud para ARI CONSULTING como documentos Word con formato de marca.

## Mejora implementada

La asignación del consultor responsable fue centralizada en una tabla interna de diez consultores. Durante la creación de una propuesta, el usuario elige un consultor por ID o nombre y el skill completa automáticamente su nombre, cargo y correo corporativo. Ya no se solicita el nombre ni el correo manualmente.

Los nombres, cargos y direcciones de correo de esta tabla son datos ficticios de demostración.

## Contenido

- `SKILL.md`: instrucciones y reglas operativas del skill.
- `DOCS/`: catálogo de servicios, plantilla de propuesta y guía de marca.
- `agents/openai.yaml`: metadatos para la interfaz de Codex.

## Uso

Instala o copia la carpeta `ari-proposal-generator` dentro de tu directorio de skills de Codex. Después, invoca `ari-proposal-generator` al solicitar una nueva propuesta comercial de ARI CONSULTING.
