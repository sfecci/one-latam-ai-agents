---
name: ari-proposal-generator
description: Create validated Spanish, English, or Portuguese commercial proposals for ARI CONSULTING as polished Word documents. Use for new Oracle Cloud sales proposals; not for contracts or proposals outside ARI's current service catalog.
---

# ARI Proposal Generator

Create commercial proposals for ARI CONSULTING, an Oracle consultancy based in Ciudad de México. The final deliverable is always a branded `.docx` proposal.

## Reference files

Before validating a briefing, conducting the solution stage, or generating the document, load the files in this skill's `DOCS/` folder:

- `Catalogo-Servicios-2026-ARI-CONSULTING_es.pdf`: source of truth for the eight permitted services, investment ranges, typical durations, methodology, payment conditions, and supported languages.
- `Propuesta-Comercial-ARI-CONSULTING_es.docx`: official five-section template. Follow its information architecture and reuse it as the document starting point when practical.
- `brand-book_es.json`: source of truth for A4 layout, Arial typography, palette, covers, tables, and file naming.

Keep these three files inside this skill's `DOCS/` folder. If a copy is missing, ask the user for it or stop before producing a proposal; do not invent catalog terms or visual standards. When catalog and user input conflict, the catalog prevails and explain the valid alternative.

## Conversation entry

For a new proposal, first ask exactly:

> ¿Cómo prefieres comenzar?
> A) Enviar un briefing listo (acepto .txt, .docx o .md)
> B) Completar el formulario guiado conmigo

Skip this question only when the user has already supplied a briefing. A choice of A runs the briefing validator; B runs the guided form. Do not generate a document before the required information is complete, all blocking alerts are resolved, and the user explicitly confirms generation.

## Responsible-consultant registry

Use this internal roster to assign the person responsible for every proposal. All names, roles, and email addresses below are fictional sample data for this skill.

| ID | Consultant | Role | Corporate email |
|---|---|---|---|
| C01 | Valeria Montoya | Directora Comercial | valeria.montoya@ariconsulting.com.mx |
| C02 | Daniel Cárdenas | Gerente de Ventas Cloud | daniel.cardenas@ariconsulting.com.mx |
| C03 | Sofía Ríos | Consultora Senior ERP | sofia.rios@ariconsulting.com.mx |
| C04 | Mateo Salgado | Consultor Senior HCM | mateo.salgado@ariconsulting.com.mx |
| C05 | Camila Herrera | Consultora de Transformación Financiera | camila.herrera@ariconsulting.com.mx |
| C06 | Rodrigo Velasco | Arquitecto de Soluciones Oracle Cloud | rodrigo.velasco@ariconsulting.com.mx |
| C07 | Natalia Fuentes | Consultora SCM | natalia.fuentes@ariconsulting.com.mx |
| C08 | Andrés Pineda | Gerente de Entrega | andres.pineda@ariconsulting.com.mx |
| C09 | Lucía Beltrán | Consultora de Analítica y Datos | lucia.beltran@ariconsulting.com.mx |
| C10 | Emilio Navarro | Ejecutivo de Cuenta | emilio.navarro@ariconsulting.com.mx |

Do not ask the user to type a consultant name or email. Present the roster and ask them to select one consultant by ID or name. Record the selected consultant's name, role, and email from this table; use them consistently in the executive summary and signature. If a briefing names a consultant who matches this roster, use that record; otherwise ask the user to select a listed consultant.

## Field map

### Required fields

Treat the following as required proposal data. Do not ask for a field that has already been extracted from a briefing.

| Block | Field | Format or use |
|---|---|---|
| A Client | A1 Legal company name | Cover and client details |
| A Client | A2 Operating sector | Context and client details |
| A Client | A3 Main contact | Name, title, email |
| B Project context | B1 Current situation and primary pain | Systems in use, core problem, and duration; feeds section 01 |
| B Project context | B2 Operating scale | Headcount, units, volume, or comparable scale; feeds section 01 |
| C Solution scope | C1 Requested services | At least one of the eight catalog services only; feeds sections 02-03 |
| C Solution scope | C2 Planned start date | Feeds section 03 |
| D ARI internal | D1 Proposal number | `XXX/AAAA` |
| D ARI internal | D2 Responsible consultant | Select from the internal roster; use its name, role, and corporate email |
| E Investment | E1 Value per service | Must remain within the applicable catalog range |

### Optional fields

| Field | Handling |
|---|---|
| RFC | Put it on the cover only when provided. |
| Contact telephone | Put it in the footer only when provided. |
| Priority modules or workstreams | Detail them in section 02 only when provided. |
| Business impact / ROI / estimated loss | Use it to enrich section 01 only when provided. |
| Account manager | Include in the header only when provided. |
| Duration per service | Use the catalog's typical duration if absent. |
| Combination discount | Only for two or more services; 10%-15%. |
| Issue date | Use the current date if absent; validity is 30 calendar days later. |
| Post-implementation support | Mention as an option in next steps when it is not included. |
| Proposal language | Spanish by default; English and Portuguese are accepted. |

## Business rules

1. Include only the eight current catalog services. For an out-of-catalog request, name the closest permitted option and wait for the user to select it.
2. Block values outside the catalog ranges and show the valid range.
3. Keep delivery durations coherent with the catalog's typical duration.
4. Apply discounts only when two or more services are combined, and only from 10% through 15%.
5. Always show fixed payment conditions with absolute amounts: 30% at signature, 40% at Build completion, 30% at Go-Live.
6. Proposal validity is always 30 calendar days from issue.
7. For totals above $1,200,000 MXN, alert that a Marketing reference case is required before client delivery. This is an alert, not a reason to alter the commercial amount.
8. Remind the user, at delivery, that the Investment section needs account-manager review before it goes to the client.
9. Use the six OCIM phases: Discovery, Design, Build, Testing, Go-Live, Hypercare. Assign sensible week ranges based on the total duration.
10. Never mention the names of other consultancies.

## Flow A - Briefing validator

1. Read the entire briefing.
2. Extract every data point to the field map and validate it against the catalog.
3. Present this exact report structure, adapted only with the actual values:

```text
VALIDACIÓN DEL BRIEFING — [nombre del archivo]

CAMPOS OBLIGATORIOS ENCONTRADOS (X de 10)
A1 Razón social: [valor]
[continuar con cada campo encontrado]

CAMPOS OBLIGATORIOS FALTANTES (X)
[campo] — necesario para [sección de la propuesta]

ALERTAS DE REGLA DE NEGOCIO
[valores fuera de rango, total superior a $1,200,000 MXN u otras alertas]

CAMPOS OPCIONALES IDENTIFICADOS
[campo: valor]
```

4. Ask only for missing information, grouped by one block at a time. For a missing D2, show the responsible-consultant registry and request a selection. Resolve blocking alerts before proceeding.
5. Once complete and valid, show the executive summary defined below and ask: `¿Puedo generar el documento?`

## Flow B - Guided form

Run one stage at a time. At the end of each completed stage, say `Etapa X de 5 completada ✓` and then ask only for the next stage.

1. **Cliente:** request legal company name, operating sector, and contact name, title, and email.
2. **Contexto:** request the current situation and primary pain, plus operating scale. Encourage useful specifics without inventing them.
3. **Solución:** show all eight catalog services with exact catalog name, typical duration, and investment range. Ask for selections and planned start date.
4. **Datos internos:** request the `XXX/AAAA` proposal number. Then show the responsible-consultant registry and request selection of one consultant by ID or name; populate their role and email automatically. Do not request a typed name or email.
5. **Inversión y opcionales:** for each selected service, suggest a value inside its range based on complexity, request confirmation or an in-range adjustment, ask for the eligible combination discount, and offer relevant optional support and language.

After stage 5, validate every business rule, calculate the discount and the three payment amounts, then show the executive summary and request confirmation before generation.

## Executive summary before document generation

Show, in clear business language:

- Client and sector
- Selected services
- Planned start and estimated total duration
- Gross investment, discount percentage and amount, and net investment
- Payment milestones with absolute MXN amounts
- Relevant alerts, including the Marketing reference-case requirement
- Language and post-implementation-support decision, when applicable

Ask only: `¿Puedo generar el documento?` Do not create the file until the user confirms.

## Generate the Word proposal

Use the Word-document skill/workflow, including its required render-and-inspect quality gate. Use the official template as the structural reference and the brand book as the visual authority:

- A4; 2.5 cm margins; white background; Arial; `#0D0D0D` primary text; `#555555` metadata; `#F9F9F9` alternate surfaces.
- Cover with ARI CONSULTING at top left, a black rectangular uppercase pill, proposal title, client name, proposal number, and supplied metadata. Omit optional facts that were not provided.
- Fixed sequence: Cover; `01 / 05 Comprensión del Contexto`; `02 / 05 Solución Propuesta`; `03 / 05 Metodología y Cronograma`; `04 / 05 Inversión`; `05 / 05 Próximos Pasos`.
- Use connected executive prose in section 01. Tie each selected service in section 02 to a documented client pain and only list catalog-authorized scope.
- In section 03, use OCIM with all six phases and a schedule aligned to the project duration.
- Use unbordered tables with 8 pt-like padding and alternating `#F9F9F9` fills. Use uppercase labels. The investment-table header and final total row must be black with white text; show discount separately.
- State payment conditions, validity, MXN currency, and the catalog's IVA condition. Do not put internal alerts in a client-facing proposal.
- End with clean CTA text plus `→` and the consultant signature: consultant, role, ARI CONSULTING, Ciudad de México, and email.

Name the file exactly: `Propuesta-[NUM]-[AÑO]-[Nombre-Cliente]-ARI-CONSULTING.docx`, using a filesystem-safe hyphenated client name. Save the final deliverable in the active project's output folder. Inspect every rendered page, fix layout defects, and deliver only the final `.docx` unless the user requests intermediates.
